package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Oceny extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oceny);


        String[] nazwyPrzedmiotow = getResources().getStringArray(R.array.tablica);
        int[] idTextViews = { R.id.textSubject1, R.id.textSubject2, R.id.textSubject3, R.id.textSubject4, R.id.textSubject5, R.id.textSubject6, R.id.textSubject7, R.id.textSubject8, R.id.textSubject9, R.id.textSubject10, R.id.textSubject11, R.id.textSubject12, R.id.textSubject13, R.id.textSubject14, R.id.textSubject15 };
        int[] idRadioGroups = { R.id.RadioGroup1, R.id.RadioGroup2, R.id.RadioGroup3, R.id.RadioGroup4, R.id.RadioGroup5, R.id.RadioGroup6, R.id.RadioGroup7, R.id.RadioGroup8, R.id.RadioGroup9, R.id.RadioGroup10, R.id.RadioGroup11, R.id.RadioGroup12, R.id.RadioGroup13, R.id.RadioGroup14, R.id.RadioGroup15};
        Integer liczbaPrzedmiotow = getIntent().getIntExtra("KLUCZ", 0);

        for (int i = 0; i < liczbaPrzedmiotow; i++) {
            RadioGroup radioGroup = findViewById(idRadioGroups[i]);
            radioGroup.setOrientation(RadioGroup.HORIZONTAL);
            TextView textView = findViewById(idTextViews[i]);
            textView.setText(nazwyPrzedmiotow[i]);

            int liczbaOcen = 4;
            int idRadioButton = 1;
            for (int j = 0; j < liczbaOcen; j++) {
                RadioButton radioButton = new RadioButton(this);
                radioButton.setText(String.valueOf(idRadioButton+1));
                radioButton.setId(idRadioButton+1);
                radioGroup.addView(radioButton);
                idRadioButton++;
            }
        }
        for(int i = liczbaPrzedmiotow; i<15; i++){
            TextView textHide = findViewById(idTextViews[i]);
            textHide.setVisibility(View.GONE);
        }


        Button button = (Button) findViewById(R.id.button4);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Double srednia = 0.0;
                for(int i = 0; i < liczbaPrzedmiotow; i++){
                    RadioGroup radioGroup = findViewById(idRadioGroups[i]);
                    int selectedId = radioGroup.getCheckedRadioButtonId();
                    if (selectedId != -1) { // sprawdzamy, czy jakakolwiek opcja została zaznaczona
                        RadioButton radioButton = findViewById(selectedId);
                        int ocena = Integer.parseInt(radioButton.getText().toString());
                        srednia += ocena;
                    }
                }
                srednia /= liczbaPrzedmiotow;
                Intent intent2 = new Intent();
                intent2.putExtra("SREDNIA", srednia.toString());
                setResult(78, intent2);
                Oceny.super.onBackPressed();
            }
        });


    }
}